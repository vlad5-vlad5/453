# OTT-Play FOSS Playlist Converter — добавление страны к названию канала

Этот конвертер переделывает любой IPTV плейлист `.m3u / .m3u8` так, чтобы **при перемотке и просмотре каналов в OTT-Play FOSS рядом с названием канала отображалась страна**.

## Что делает?

**Было:**
```
#EXTINF:-1 group-title="USA",CNN
#EXTINF:-1 group-title="UK",BBC One
#EXTINF:-1 group-title="Germany",ZDF
```

**Стало (формат который вы выбрали: 🇺🇸 + русский):**
```
#EXTINF:-1 group-title="США" tvg-country="US",🇺🇸 CNN [США]
#EXTINF:-1 group-title="Великобритания" tvg-country="GB",🇬🇧 BBC One [Великобритания]
#EXTINF:-1 group-title="Германия" tvg-country="DE",🇩🇪 ZDF [Германия]
```

В OTT-Play FOSS при переключении каналов вы сразу видите:
> `🇺🇸 CNN [США]`, `🇬🇧 BBC One [Великобритания]`, `🇩🇪 ZDF [Германия]`

## Поддерживаемые страны (60+)

США, Великобритания, Германия, Франция, Италия, Испания, Португалия, Нидерланды, Бельгия, Швейцария, Австрия, Польша, Чехия, Словакия, Венгрия, Румыния, Болгария, Греция, Турция, Россия, Украина, Беларусь, Казахстан, Молдова, Армения, Азербайджан, Грузия, Литва, Латвия, Эстония, Финляндия, Швеция, Норвегия, Дания, Исландия, Ирландия, Канада, Австралия, Новая Зеландия, Бразилия, Аргентина, Мексика, Индия, Пакистан, Саудовская Аравия, ОАЭ, Израиль, Япония, Корея, Китай, Сербия, Хорватия, Словения, Албания, Узбекистан, Киргизия, Таджикистан, Туркменистан и др.

Определяет страну из:
- `group-title="USA"` / `group-title="Germany"`
- `tvg-country="US"`
- Префиксов в названии: `US: CNN`, `DE | ZDF`, `[UK] BBC`
- Названий групп на разных языках: `Deutschland`, `Turkiye`, `Polska` и т.д.

## Как использовать

### 1. Базовое использование (рекомендуется для OTT-Play FOSS)

```bash
python3 playlist_converter.py ваш_плейлист.m3u
```

Создаст файл `ваш_плейлист_ott.m3u` в формате:
```
🇺🇸 Название канала [США]
```

### 2. Все форматы отображения

```bash
# [США] BBC One - страна в начале (хорошо видно при перемотке)
python3 playlist_converter.py input.m3u output.m3u --format prefix_bracket --lang ru

# BBC One [США] - страна в конце
python3 playlist_converter.py input.m3u output.m3u --format suffix_bracket --lang ru

# BBC One | США - через разделитель
python3 playlist_converter.py input.m3u output.m3u --format pipe --lang ru

# 🇺🇸 BBC One [США] - с флагом (РЕКОМЕНДУЕТСЯ для OTT-Play FOSS) - ВЫБРАННЫЙ ВАМИ
python3 playlist_converter.py input.m3u output.m3u --format flag_prefix --lang ru

# BBC One 🇺🇸 [США] - флаг в конце
python3 playlist_converter.py input.m3u output.m3u --format flag_suffix --lang ru
```

### 3. Язык страны

```bash
--lang ru    # На русском: США, Германия, Великобритания (ваш выбор)
--lang en    # На английском: USA, Germany, UK
--lang both  # Двойное: USA / США
```

### 4. Сохранить оригинальные группы

По умолчанию `group-title` перезаписывается на название страны (удобно для группировки в OTT-Play FOSS).
Если хотите оставить оригинальные группы:

```bash
python3 playlist_converter.py input.m3u output.m3u --keep-group
```

### 5. Загрузка по ссылке

```bash
python3 playlist_converter.py https://example.com/playlist.m3u playlist_ott.m3u
```

### 6. Подробный вывод

```bash
python3 playlist_converter.py input.m3u --verbose
```

Выведет:
```
[GB] BBC One -> 🇬🇧 BBC One [Великобритания]
[DE] ZDF -> 🇩🇪 ZDF [Германия]
[US] CNN -> 🇺🇸 CNN [США]
...
✅ Готово! Обработано 14 каналов
```

## Примеры

В папке есть готовые примеры:

- `example.m3u` - входной пример
- `example_ott.m3u` - результат в формате 🇺🇸 Название [США] (ваш формат)
- `example_prefix.m3u` - результат [США] Название
- `example_pipe.m3u` - результат Название | США

### Пример вывода для OTT-Play FOSS (flag_prefix + ru):

```
#EXTM3U
#EXTINF:-1 tvg-id="BBC One" group-title="Великобритания" tvg-country="GB",🇬🇧 BBC One [Великобритания]
http://...
#EXTINF:-1 tvg-id="CNN" group-title="США" tvg-country="US",🇺🇸 CNN [США]
http://...
#EXTINF:-1 tvg-id="ZDF" group-title="Германия" tvg-country="DE",🇩🇪 ZDF [Германия]
http://...
```

При перемотке в OTT-Play FOSS вы видите сразу флаг и страну!

## Установка в OTT-Play FOSS

1. Сконвертируйте плейлист:
   ```bash
   python3 playlist_converter.py ваш_плейлист.m3u ott_playlist.m3u
   ```

2. Загрузите `ott_playlist.m3u` в OTT-Play FOSS:
   - Откройте OTT-Play FOSS
   - Настройки -> Плейлисты -> Добавить плейлист
   - Выберите файл или укажите путь

3. При переключении каналов теперь отображается страна!

## Как работает определение страны?

1. Проверяет атрибут `tvg-country="US"`
2. Проверяет `group-title="USA"` (поддерживает 100+ вариантов написания)
3. Ищет префиксы: `US:`, `UK |`, `[DE]`, `USA -` и т.д.
4. Ищет названия стран в названии канала
5. Проверяет `tvg-name` и `tvg-id`

Если страна не определена - канал остается без изменений.

## Требования

- Python 3.8+
- Никаких внешних зависимостей!

## Для вашего плейлиста

**Загрузите ваш .m3u файл в этот чат** или положите его в папку репозитория и запустите:

```bash
python3 playlist_converter.py ваш_файл.m3u --format flag_prefix --lang ru
```

Готовый файл можно сразу использовать в OTT-Play FOSS.

---

Сделано для удобного просмотра IPTV в OTT-Play FOSS с отображением страны канала при перемотке.
