# Как скачать файлы если нет кнопки Скачать

## Способ 1: GitHub (самый простой)
1. Откройте: https://github.com/vlad5-vlad5/453/tree/arena/01a0ea25-453
2. Нажмите на файл index.html
3. Нажмите кнопку "Raw" или "Download raw file"
4. Сохраните файл: Ctrl+S

## Способ 2: Скопировать содержимое
1. В Arena откройте файл index.html (он уже открыт)
2. Нажмите кнопку "Copy" или выделите весь текст Ctrl+A, Ctrl+C
3. Создайте новый файл на компьютере: index.html
4. Вставьте содержимое Ctrl+V и сохраните
5. Откройте двойным кликом в браузере

## Способ 3: Использовать Python напрямую
Скачайте только playlist_converter.py и запустите:
python3 playlist_converter.py ваш_файл.m3u --format flag_prefix --lang ru
