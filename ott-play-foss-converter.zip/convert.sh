#!/bin/bash
# Быстрая конвертация для OTT-Play FOSS
# Использование: ./convert.sh ваш_плейлист.m3u

set -e

INPUT="${1:-}"
FORMAT="${2:-flag_prefix}"
LANG="${3:-ru}"

if [ -z "$INPUT" ]; then
    echo "Использование: ./convert.sh <файл.m3u> [формат] [язык]"
    echo ""
    echo "Форматы:"
    echo "  flag_prefix     - 🇺🇸 Название [США] (рекомендуется для OTT-Play FOSS)"
    echo "  prefix_bracket  - [США] Название"
    echo "  suffix_bracket  - Название [США]"
    echo "  pipe            - Название | США"
    echo ""
    echo "Языки: ru, en, both"
    echo ""
    echo "Примеры:"
    echo "  ./convert.sh playlist.m3u"
    echo "  ./convert.sh playlist.m3u flag_prefix ru"
    echo "  ./convert.sh https://example.com/playlist.m3u"
    echo ""
    echo "Файлы в текущей папке:"
    ls -1 *.m3u *.m3u8 2>/dev/null || echo "  .m3u файлов не найдено"
    exit 1
fi

echo "🔄 Конвертирую $INPUT -> формат: $FORMAT, язык: $LANG"
python3 playlist_converter.py "$INPUT" --format "$FORMAT" --lang "$LANG" --verbose
echo ""
echo "✅ Готово! Загрузите *_ott.m3u в OTT-Play FOSS"
